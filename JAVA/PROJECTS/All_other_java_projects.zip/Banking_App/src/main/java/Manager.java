
public class Manager {
	
	private int manId;
	private String manName;

	public Manager(int manId, String manName) {
		super();
		this.manId = manId;
		this.manName = manName;
	}

	public int getManId() {
		return manId;
	}

	public void setManId(int manId) {
		this.manId = manId;
	}

	public String getManName() {
		return manName;
	}

	public void setManName(String manName) {
		this.manName = manName;
	}	

	
}
