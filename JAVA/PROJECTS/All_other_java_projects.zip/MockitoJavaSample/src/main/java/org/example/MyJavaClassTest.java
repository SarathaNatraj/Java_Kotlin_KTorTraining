package org.example;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

class MyJavaClassTest {

    MyJavaClass myclass = new MyJavaClass();
    //testing mocked object - mockito frame  work
    @Test
    void add() {
        MyJavaClass myJavaClass = Mockito.mock(MyJavaClass.class);
        int expected = 8;
        when(myJavaClass.addTwo(5,3)).thenReturn(expected);

        int actual = myJavaClass.addTwo(5,2);
        assertEquals(expected,actual);
    }

    //testing with real object new operator - junit - functional testing
    @Test
    void addRealClassObject() {
        int expected = 7;

        int actual = myclass.addTwo(5,2);
        assertEquals(expected,actual);

        MyJavaClass spyMy = spy(MyJavaClass.class);
        assertEquals(expected, spyMy.addTwo(5,2));
    }
@Test
public void  demo(){
    List<String> list = new ArrayList<>();
    List<String> listSpy = spy(list);

    listSpy.add("first-element");
    System.out.println(listSpy.get(0));

    assertEquals("first-element", listSpy.get(0));


    when(listSpy.get(0)).thenReturn("second-element");

}
    @Test
    void printMessage() {
    }

    @Test
    void area() {
    }
}