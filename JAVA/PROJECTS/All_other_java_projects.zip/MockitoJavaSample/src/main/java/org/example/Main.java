package org.example;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
    public int add(int a, int b){
        return 0;
    }
}