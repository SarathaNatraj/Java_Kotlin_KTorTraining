package org.example;

public class MyJavaClass {




    public static void add(int a,int b){
        int result = a + b;
        System.out.println("printing inside Java class :"+result);
    }

    public  int addTwo(int a,int b){
        int result = a + b;
        System.out.println("printing inside Java class :"+result);
        return result;
    }
    public static final void printMessage( String message) {

        String var1 = message;
        System.out.println(var1);
    }
    public static int area(int l, int b){
        int result = l * b;
        return result;
    }


}

