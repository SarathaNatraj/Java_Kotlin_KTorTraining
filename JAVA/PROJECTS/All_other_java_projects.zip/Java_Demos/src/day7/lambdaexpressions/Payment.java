package day7.lambdaexpressions;

public interface Payment {
	void display();
}
