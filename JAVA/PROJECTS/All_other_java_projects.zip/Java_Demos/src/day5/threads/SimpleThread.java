package day5.threads;

class SimpleThread extends Thread {
    public void run() {
        System.out.println("thread is running...");
    }

    public static void main(String args[]) {
        SimpleThread t1 = new SimpleThread();
        t1.start();
        t1.setName("Download Thread");
        System.out.println("t1"+t1);
    }
}