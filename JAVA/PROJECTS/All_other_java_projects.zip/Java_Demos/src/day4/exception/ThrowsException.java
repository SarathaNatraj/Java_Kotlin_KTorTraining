package day4.exception;

class ThrowsExeception {

    // This method throws an exception
    // to be handled
    // by caller or caller
    // of caller and so on.
    static void fun() throws Exception {
        System.out.println("Inside fun(). ");
		IllegalAccessException iae =new  IllegalAccessException("ahhhs");
		throw iae;
	}

    // This is a caller function
    public static void main(String args[]) {
        try {
            fun();

        }catch (ArithmeticException e) {
            // TODO: handle exception
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}