package day4.exception;

import static org.junit.jupiter.api.Assertions.*;

class ThrowExceptionTest {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @org.junit.jupiter.api.Test
    void fun() {
    }
}