package day9.generics;

//Java program to show working of user defined
//Generic functions

import day6.collections.Student;

class GenericMethodType {
	// A Generic method example
	static <T> void genericDisplay(T element) {
		System.out.println(element.getClass().getName() + " = " + element);
	}

	// Driver method
	public static void main(String[] args) {
		// Calling generic method with Integer argument
		genericDisplay(11);

		// Calling generic method with String argument
		genericDisplay("GeeksForGeeks");

		// Calling generic method with double argument
		genericDisplay(1.0);
		Student s = new Student(1, "Mohan");
		genericDisplay(s);
	}
}