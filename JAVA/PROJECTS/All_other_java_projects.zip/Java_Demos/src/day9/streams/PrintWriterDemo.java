package day9.streams;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class PrintWriterDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		usingPrintWriter();
		System.out.println("Write in to file");
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}
	
	public static void usingPrintWriter() throws IOException 
	{
	  String textToAppend = "Happy JAVA Learning Kotlin !!";
	   
	  	FileWriter fileWriter = new FileWriter("D://samplefile.tx"); //Set true for append mode
		FileOutputStream fos = new FileOutputStream(("D://sample.txt"));
	    PrintWriter printWriter = new PrintWriter(fos);
	    printWriter.println(textToAppend);  //New line
		fos.close();
		fileWriter.close();
	    printWriter.close();
	}
}
