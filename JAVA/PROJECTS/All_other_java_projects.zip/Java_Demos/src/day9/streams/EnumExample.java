package day9.streams;

enum Car{

    MARUTI,HONDA,TESLA;

};

    public class EnumExample{

        public static void main(String [] args) {

             Car c1= Car.HONDA;

            System.out.println(c1);

        }

    }
