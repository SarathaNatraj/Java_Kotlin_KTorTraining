import java.util.ArrayList;
import java.util.List;

public class sample {
    public static void main(String[] args) {
        List<String> words = new ArrayList<>();
        words.add("forest");
        words.add("Bible");
       words.add(null);
        words.add("test");
        int nOfChars = 0;
        String x=null;
        for(int i =0;i <words.size();i++) {

            int n = words.get(i).length();
                    nOfChars = n+nOfChars;
            System.out.println(words.get(i) +" has "+n+" characters in the list");
        }

    }
}
