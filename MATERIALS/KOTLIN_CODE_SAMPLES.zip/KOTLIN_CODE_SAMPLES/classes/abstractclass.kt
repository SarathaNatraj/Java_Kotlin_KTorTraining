/*

abstract class PolygonAbs1 {
   abstract fun draw()
   abstract fun point()
   fun shape(){
       println(" general shape")
   }
}
class RectangleAbs: PolygonAbs1() {
   override fun draw() {
       // draw the rectangle
       println(" drawing the rect")
   }
   override fun point() {
       // point the rectangle
       println(" pointing the rect")
   }

}
fun main(){
   val rect = RectangleAbs()
   rect.draw()
   rect.point()
   rect.shape()
}
*/
