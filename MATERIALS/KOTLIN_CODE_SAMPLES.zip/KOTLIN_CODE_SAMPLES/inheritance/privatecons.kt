/*
class PrivateCons private constructor(val a : Int)



fun main(){
    println(PrivateCons(100))
}*/
