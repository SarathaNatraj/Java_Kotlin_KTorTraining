/*
open class Member(val name : String,var age: Int){
    init{
        println(" name  is $name")
    }
}
class Employee1(name : String, age: Int): Member(val name : String,var age: Int){
    fun printSalary(){
        println(" salary is 250000")
    }
}
fun main(){
    val e = Employee1("Engineering")
    e.printSalary()
}
*/
